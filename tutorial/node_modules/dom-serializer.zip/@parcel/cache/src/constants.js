// @flow strict-local

// Node has a file size limit of 2 GB
export const WRITE_LIMIT_CHUNK = 2 * 1024 ** 3;
