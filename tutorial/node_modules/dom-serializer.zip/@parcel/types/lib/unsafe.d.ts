export type ConfigResult = any;
export type AST = {
  type: string;
  version: string;
  program: any;
};
