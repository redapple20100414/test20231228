import * as idx from './index.js';
new URL('index.js', import.meta.url);
import('index.js')
