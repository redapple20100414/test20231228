const {Transformer} = require('@parcel/plugin');

module.exports = new Transformer({
  transform(asset) {
    return [asset];
  }
});
