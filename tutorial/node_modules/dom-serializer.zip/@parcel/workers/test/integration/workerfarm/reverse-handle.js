function run(workerApi, handle) {
  return workerApi.runHandle(handle, []);
}

exports.run = run;
