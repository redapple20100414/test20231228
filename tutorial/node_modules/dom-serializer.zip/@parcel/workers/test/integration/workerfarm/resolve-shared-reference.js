function run(workerApi, ref) {
  return ref === workerApi.resolveSharedReference(workerApi.getSharedReference(ref));
}

exports.run = run;
