function run(_, data) {
  return data;
}

exports.run = run;
