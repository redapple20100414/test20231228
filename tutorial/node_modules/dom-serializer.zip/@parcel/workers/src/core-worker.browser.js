// @flow
// eslint-disable-next-line monorepo/no-internal-import
module.exports = require('@parcel/core/src/worker.js');
