// This is used only in browser builds
module.exports = {};
