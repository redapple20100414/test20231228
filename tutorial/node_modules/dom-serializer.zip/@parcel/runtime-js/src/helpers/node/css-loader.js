// loading a CSS style is a no-op in Node.js
module.exports = function loadCSSBundle() {
  return Promise.resolve();
};
