function load(id) {
  // eslint-disable-next-line no-undef
  return __parcel__import__(require('../bundle-manifest').resolve(id));
}

module.exports = load;
