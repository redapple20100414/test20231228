// @flow

export type BabelConfig = {|
  plugins?: Array<any>,
  presets?: Array<any>,
|};
