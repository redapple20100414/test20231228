// @flow strict-local

export const BABEL_CORE_RANGE = '^7.12.0';
